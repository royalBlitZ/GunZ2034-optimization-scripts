using System;
using System.ServiceProcess;
using System.ComponentModel;
using System.Configuration.Install;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Threading;
using System.Management;
using System.Security;
using System.Security.Principal;
using System.Runtime.ExceptionServices;

[assembly: AssemblyProduct("Purge Memory Cache Service")]

namespace PMCS
{
    // enumeration of all possible schedules for initiation of the purge
    internal enum PurgeSchedules
    {
        Timer,  // use timer to initiate the purge (should specify the timer interval in minutes)
        Start,  // use process start monitoring to initiate the purge (should list the names of processes to monitor) 
		Stop    // use process stop monitoring to initiate the purge (should list the names of processes to monitor) 
    }

    // enumeration of all possible targets of the purge
    [Flags]
    internal enum PurgeTargets
    {
        StandbyList = 1,    // purge the standby lists
        FileCache   = 2     // purge the file cache
    }

    public sealed class WindowsService : ServiceBase
    {
        public static WindowsService Instance;

        static void Main()
        {
            Instance = new WindowsService();
            ServiceBase.Run(Instance);
            Instance = null;
        }
		
        public WindowsService()
        {
            this.ServiceName = "PMCS";
			this.AutoLog = false;

            // These Flags set whether or not to handle that specific
            //  type of event. Set to true if you need it, false otherwise.
            this.CanStop = true;
            this.CanHandlePowerEvent = false;
            this.CanHandleSessionChangeEvent = false;
            this.CanPauseAndContinue = false;
            this.CanShutdown = false;
        }

        public void LogEvent(EventLogEntryType eventType, int eventId, String message,  params Object[] args)
        {
            if(null == this.EventLog)
                return;
            try { 
                this.EventLog.WriteEntry(String.Format(message, args), eventType); 
            }
            catch {}
        }

        public void LogEvent(EventLogEntryType eventType, String message,  params Object[] args)
        {
            LogEvent(eventType, 0, message, args);
        }

        EventLog pcmsLog = null;
        public override EventLog EventLog 
        {
            get
            {
                if (pcmsLog == null)
                {
                    // create or open our own event log
                    try
                    {
                        EventSourceCreationData sourceData = new EventSourceCreationData(this.ServiceName, "PurgeMemoryCacheService");
                        if (!EventLog.SourceExists(sourceData.Source))
                        {
                            EventLog.CreateEventSource(sourceData);
                        }
                        pcmsLog = new EventLog(sourceData.LogName, ".", sourceData.Source);
                    }
                    catch { }
                }
                return pcmsLog;
            }
        }

        protected override void OnStart(string[] args)
        {
            base.OnStart(args);

			LogEvent(EventLogEntryType.Information, "Starting the service...");
			
            try
            {
                // parse queries from ini-file
                if (!PurgeQuery.ParseIniFile()) 
                {
                    this.Stop();
                    return;
                }

                // grant the privilege for purging the standby lists
                SetIncreasePrivilege("SeProfileSingleProcessPrivilege");

                // grant the privilege for purging the file cache
                SetIncreasePrivilege("SeIncreaseQuotaPrivilege");

                // start the queries
                PurgeQuery.Start();
            }
            catch (Exception ex)
            {
                LogEvent(EventLogEntryType.Error, ex.ToString());
                this.Stop();
            }
        }

        protected override void OnStop()
        {
			LogEvent(EventLogEntryType.Information, "Stopping the service...");

            try { PurgeQuery.Stop(); }
            catch { }

            var log = this.EventLog;
            if (log != null)
                log.Dispose();
        }

        [SuppressUnmanagedCodeSecurity]
        void SetIncreasePrivilege(string privilegeName)
        {
            using (WindowsIdentity current = WindowsIdentity.GetCurrent(TokenAccessLevels.Query | TokenAccessLevels.AdjustPrivileges))
            {
                TokPriv1Luid newst;
                newst.Count = 1;
                newst.Luid = 0L;
                newst.Attr = 2; //SE_PRIVILEGE_ENABLED;
                if (!LookupPrivilegeValue(null, privilegeName, ref newst.Luid))
                    throw new Exception("Error in LookupPrivilegeValue: ", new Win32Exception(Marshal.GetLastWin32Error()));
                if(!AdjustTokenPrivileges(current.Token, false, ref newst, 0, IntPtr.Zero, IntPtr.Zero))
                    throw new Exception("Error in AdjustTokenPrivileges: ", new Win32Exception(Marshal.GetLastWin32Error()));
            }
        } 

        // P/Invoke stuff

        [StructLayout(LayoutKind.Sequential, Pack = 1)] // DO NOT REMOVE "Pack = 1"
        internal struct TokPriv1Luid
        {
            public int Count;
            public long Luid;
            public int Attr;
        }

        [DllImport("advapi32.dll", SetLastError = true)]
        static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

        [DllImport("advapi32.dll", SetLastError = true)]
        static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen);
    }

    internal sealed class PurgeQuery: IDisposable
    {
        static BlockingCollection<PurgeQuery> queriesQueue = new BlockingCollection<PurgeQuery>();
        static List<PurgeQuery> queries = new List<PurgeQuery>();
        static ManagementScope wmiScope;

        Timer checkTimer;
        ManagementEventWatcher wmiWatcher;
		PerformanceCounter pcFreeAndZero;

        string Query;
        PurgeTargets Targets;
        PurgeSchedules Schedule;
        TimeSpan ScheduleInterval;
        List<string> ScheduleProcesses;
        UInt64 Treshold;

        private PurgeQuery(string query, PurgeTargets targets, PurgeSchedules schedule, UInt64 treshold)
        {
            Query = query;
            Targets = targets;
            Schedule = schedule;
            Treshold = treshold;
        }

        private PurgeQuery(string query, PurgeTargets targets, PurgeSchedules schedule, TimeSpan interval, UInt64 treshold)
            : this(query, targets, schedule, treshold)
        {
            ScheduleInterval = interval;
        }

        private PurgeQuery(string query, PurgeTargets targets, PurgeSchedules schedule, List<string> processes, UInt64 treshold)
            : this(query, targets, schedule, treshold)
        {
            ScheduleProcesses = processes;
        }
		
		public override string ToString()
		{
			return Query;
		}

        public static bool ParseIniFile()
        {
            string iniFilePath = Assembly.GetExecutingAssembly().Location + ".ini";
            if (!File.Exists(iniFilePath))
            {
                WindowsService.Instance.LogEvent(EventLogEntryType.Warning, 10, "No ini-file '{0}'", iniFilePath);
                return false;
            }

            var iniFileLines = File.ReadAllLines(iniFilePath);
			
			var fullQueryPattern = new Regex(@"^purge\s+([^\)]+)\s+on\s+(\w+)\s*\(([^\)]+)\)\s+with\s+treshold\s*\(([^\)]+)\)", RegexOptions.IgnoreCase);
			var shortQueryPattern = new Regex(@"^purge\s+([^\)]+)\s+on\s+(\w+)\s*\(([^\)]+)\)$", RegexOptions.IgnoreCase);
			
            for (int i = 0; i < iniFileLines.Length; i++)
            {
                string line = iniFileLines[i].Trim();
                if (string.IsNullOrWhiteSpace(line) || line[0] == '#')   // skip empty and commented lines 
                    continue;
                var query = PurgeQuery.Parse(line, fullQueryPattern, shortQueryPattern);
                if (null == query)
                {
                    return false;
                }
                queries.Add(query);
            }

            if (queries.Count == 0)
            {
                WindowsService.Instance.LogEvent(EventLogEntryType.Warning, 10, "Empty ini-file");
                return false;
            }

            WindowsService.Instance.LogEvent(EventLogEntryType.Information, "{0} queries in ini-file:\n{1}", queries.Count, string.Join("\n", queries));
            return true;
        }

        static PurgeQuery Parse(string query, Regex fullQueryPattern, Regex shortQueryPattern)
        {
			// examples of queries
            // purge StandbyList,FileCache on timer(60) with treshold(500)
            // purge StandbyList on start(notepad.exe,%paint.exe) with treshold(500)
            // purge StandbyList on stop(notepad.exe) with treshold(500)
            // purge FileCache on timer(120)
            if(string.IsNullOrWhiteSpace(query))
                return null;

			string targetsStr, scheduleStr, scheduleOptions = "10";
            UInt64 treshold = 0;

            // try to search for full query syntax
            Match fullQueryMatch = fullQueryPattern.Match(query);
            if (fullQueryMatch.Success)
            {
				targetsStr = fullQueryMatch.Groups[1].ToString();
				scheduleStr = fullQueryMatch.Groups[2].ToString();
                scheduleOptions = fullQueryMatch.Groups[3].ToString();
				
                if (!UInt64.TryParse(fullQueryMatch.Groups[4].ToString(), out treshold))
                {
                    WindowsService.Instance.LogEvent(EventLogEntryType.Error, 20, "Wrong syntax (not a number): 'treshold({0})' in '{1}'", fullQueryMatch.Groups[4], query);
                    return null;
                }
            }
            else
            {
                // try to search for short query syntax
                Match shortQueryMatch = shortQueryPattern.Match(query);
                if (shortQueryMatch.Success)
                {
					targetsStr = shortQueryMatch.Groups[1].ToString();
					scheduleStr = shortQueryMatch.Groups[2].ToString();
                    scheduleOptions = shortQueryMatch.Groups[3].ToString();
                }
                else
                {
                    WindowsService.Instance.LogEvent(EventLogEntryType.Error, 20, "Unrecognized  syntax: '{0}'", query);
                    return null;
                }
            }

            PurgeTargets targets = PurgeTargets.StandbyList;
			if (!Enum.TryParse<PurgeTargets>(targetsStr, true, out targets))
			{
				WindowsService.Instance.LogEvent(EventLogEntryType.Error, 20, "Wrong syntax: 'purge {0}' in '{1}'", targetsStr, query);
				return null;
			}

            PurgeSchedules schedule = PurgeSchedules.Timer;
			if (!Enum.TryParse<PurgeSchedules>(scheduleStr, true, out schedule))
			{
				WindowsService.Instance.LogEvent(EventLogEntryType.Error, 20, "Wrong syntax: 'on {0}' in '{1}'", scheduleStr, query);
				return null;
			}
			
            if (schedule == PurgeSchedules.Timer)
            {
                int minutes = 10;
                if (!int.TryParse(scheduleOptions, out minutes))
                {
                    WindowsService.Instance.LogEvent(EventLogEntryType.Error, 20, "Wrong syntax: 'on {0}({1})' in '{2}'", schedule.ToString().ToLower(), scheduleOptions, query);
                    return null;
                }
				
                return new PurgeQuery(query, targets, schedule, TimeSpan.FromMinutes(minutes), treshold);
            }

            if (schedule == PurgeSchedules.Start || schedule == PurgeSchedules.Stop)
            {
                var processNames = new List<string>(scheduleOptions.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
                if (processNames.Count == 0)
                {
                    WindowsService.Instance.LogEvent(EventLogEntryType.Error, 20, "Wrong syntax: 'on {0}({1})' in '{2}'", schedule.ToString().ToLower(), scheduleOptions, query);
                    return null;
                }
				
                return new PurgeQuery(query, targets, schedule, processNames, treshold);
            }
			
            return null;
        }


        [SuppressUnmanagedCodeSecurity]
        public static void Start()
        {
            if (queries.Count == 0) // paranoid check
                return;

            if(queries.Any(qq => qq.Schedule == PurgeSchedules.Start || qq.Schedule == PurgeSchedules.Stop))
            {
                // connect to WMI
                wmiScope = new ManagementScope(@"\\.\root\cimv2");
                wmiScope.Connect();
            }

            // schedule all queries
            foreach (var query in queries)
            {
                query.StartSchedule();
            }

            // start the query execution thread
            Thread queryThread = new Thread(InvokeQuery)
            {
                IsBackground = true
            };
            queryThread.Start();
        }

        [SuppressUnmanagedCodeSecurity]
        public static void Stop()
        {
            queriesQueue.CompleteAdding();

            foreach (var query in queries)
            {
                query.Dispose();
            }

            if (wmiScope != null)
            {
                // to break current connection
                try { wmiScope.Options = new ConnectionOptions(); }
                catch { }
            }
        }

        [SuppressUnmanagedCodeSecurity]
        public void StartSchedule()
        {
            if(Schedule == PurgeSchedules.Timer)
            {
                StartTimeSchedule();
            }
            else if(Schedule == PurgeSchedules.Start)
            {
                StartWMISchedule("Win32_ProcessStartTrace");
            }
            else if(Schedule == PurgeSchedules.Stop)
            {
                StartWMISchedule("Win32_ProcessStopTrace");
            }

            if (Treshold > 0)
            {
                InitPeformanceCounter();
            }

        }

        void StartTimeSchedule()
        {
            // create timer
            this.checkTimer = new Timer(TimerEventArrived, null, ScheduleInterval, ScheduleInterval);
        }

        void StartWMISchedule(string wmiClass)
        {
            // create WMI watcher
            this.wmiWatcher = new ManagementEventWatcher(wmiScope, new EventQuery(string.Format("SELECT ProcessID FROM {0} WHERE ProcessName LIKE '{1}'", wmiClass, string.Join("' OR ProcessName LIKE '", ScheduleProcesses))));
            this.wmiWatcher.EventArrived += this.WmiEventArrived;
            this.wmiWatcher.Stopped += this.StoppedSubscription;
            this.wmiWatcher.Start();
        }

        void InitPeformanceCounter()
        {
            // initialize performance counter
            this.pcFreeAndZero = new PerformanceCounter("Memory", "Free & Zero Page List Bytes", true);
        }

        [SuppressUnmanagedCodeSecurity]
        [HandleProcessCorruptedStateExceptions]
        public void Execute()
        {
            if (queriesQueue.IsCompleted)
                return;

            try
            {
                uint res;

                // we need to check low memory state only if treshold was specified
                if (Treshold > 0)
                {
					UInt64 avail = Convert.ToUInt64(pcFreeAndZero.NextValue()) >> 20;
					
                    if (avail > Treshold)
                    {
						WindowsService.Instance.LogEvent(EventLogEntryType.Information, "Free & Zeroed memory = {0} MB\nTreshold = {1} MB", avail.ToString(), Treshold.ToString());
                        return;
                    }
                }

				// if standby list is specified among the targets
                if (0 != (Targets & PurgeTargets.StandbyList))
                {
                    Int32 SystemMemoryListInformation = 0x0050;
                    Int32 MemoryPurgeStandbyList = 4;
                    res = NtSetSystemInformation(SystemMemoryListInformation, ref MemoryPurgeStandbyList, Marshal.SizeOf(typeof(Int32)));
                    if (res != 0)
                        WindowsService.Instance.LogEvent(EventLogEntryType.Warning, 100, "Purging the {0} by the query '{1}' failed with error {2}", PurgeTargets.StandbyList.ToString(), Query, Marshal.GetLastWin32Error());
                    else
                        WindowsService.Instance.LogEvent(EventLogEntryType.Information, "{0} is purged by the query '{1}'", PurgeTargets.StandbyList.ToString(), Query);
                }

				// if file cache is specified among the targets
                if (0 != (Targets & PurgeTargets.FileCache))
                {
                    res = SetSystemFileCacheSize(IntPtr.Subtract(IntPtr.Zero, 1), IntPtr.Subtract(IntPtr.Zero, 1), 0);
                    if (res == 0)
                        WindowsService.Instance.LogEvent(EventLogEntryType.Warning, 100, "Purging the {0} by the query '{1}' failed with error {2}", PurgeTargets.FileCache.ToString(), Query, Marshal.GetLastWin32Error());
                    else
                        WindowsService.Instance.LogEvent(EventLogEntryType.Information, "{0} is purged by the query '{1}'", PurgeTargets.FileCache.ToString(), Query);
                }
            }
            catch(Exception ex)
            {
                WindowsService.Instance.LogEvent(EventLogEntryType.Warning, 100, "Unexpected error '{0}' in execution of the query '{1}'", ex.ToString(), Query);
            }
        }

        [SuppressUnmanagedCodeSecurity]
        [HandleProcessCorruptedStateExceptions]
        public void Dispose()
        {
            if (this.checkTimer != null)
            {
                try
                {
                    this.checkTimer.Dispose();
                    this.checkTimer = null;
                }
                catch { }
            }

            if (this.wmiWatcher != null)
            {
                try
                {
                    this.wmiWatcher.Stopped -= this.StoppedSubscription;
                    this.wmiWatcher.EventArrived -= this.WmiEventArrived;
                    this.wmiWatcher.Stop();
                    this.wmiWatcher.Dispose();
                    this.wmiWatcher = null;
                }
                catch { }
            }
			
			if(this.pcFreeAndZero != null)
			{
                try
                {
                    this.pcFreeAndZero.Dispose();
                }
                catch { }
			}
        }

        void TimerEventArrived(object state)
        {
			try 
			{
				queriesQueue.Add(this);
				WindowsService.Instance.LogEvent(EventLogEntryType.Information, "The query '{0}' is scheduled", Query);
			}
			catch {}
        }

        void WmiEventArrived(object sender, EventArrivedEventArgs e)
        {
			try
			{
				queriesQueue.Add(this);
				WindowsService.Instance.LogEvent(EventLogEntryType.Information, "The query '{0}' is scheduled", Query);
				e.NewEvent.Dispose();
			}
			catch {}
        }

        void StoppedSubscription(object sender, StoppedEventArgs e)
        {
            WindowsService.Instance.LogEvent(EventLogEntryType.Warning, 1000, "Schedule for the query '{0}' has been terminated with status '{1}'", Query, e.Status.ToString());
            Dispose();
        }


        static void InvokeQuery()
        {
            try
            {
                foreach (var query in queriesQueue.GetConsumingEnumerable())
                {
                    query.Execute();
                }
            }
            catch { }
        }


        // p/invoke stuff


        [DllImport("ntdll.dll", SetLastError = true)]
        static extern UInt32 NtSetSystemInformation(Int32 InfoClass, ref Int32 Info, Int32 Length);

        [DllImport("Kernel32.dll", SetLastError = true)]
        static extern UInt32 SetSystemFileCacheSize(IntPtr MinimumFileCacheSize, IntPtr MaximumFileCacheSize, UInt32 Flags);
    }

    [RunInstaller(true)]
    public sealed class WindowsServiceInstaller : Installer
    {
        /// <summary>
        /// Public Constructor for WindowsServiceInstaller.
        /// - Put all of your Initialization code here.
        /// </summary>
        public WindowsServiceInstaller()
        {
            ServiceProcessInstaller serviceProcessInstaller =
                               new ServiceProcessInstaller();
            ServiceInstaller serviceInstaller = new ServiceInstaller();

            //# Service Account Information
            serviceProcessInstaller.Account = ServiceAccount.LocalSystem;
            serviceProcessInstaller.Username = null;
            serviceProcessInstaller.Password = null;

            //# Service Information
            serviceInstaller.DisplayName = "Purge Memory Cache Service";
            serviceInstaller.StartType = ServiceStartMode.Automatic;

            //# This must be identical to the WindowsService.ServiceBase name
            //# set in the constructor of WindowsService.cs
            serviceInstaller.ServiceName = "PMCS";

            this.Installers.Add(serviceProcessInstaller);
            this.Installers.Add(serviceInstaller);
        }
    }
}