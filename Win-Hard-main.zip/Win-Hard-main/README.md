# Win-Hard
Windows 10 Hardening Script

Win-Hard will disable unnecessary services, Appx Packages and Privacy Settings.
***Under Process***

Feel free to edit...
