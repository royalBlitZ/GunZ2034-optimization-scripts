# librapid
Optimization Windows Tcp Server Library

1. IOCP
2. Virtual Memory
3. Accept Socket Polling
4. Reuse Socket descriptor (not object pool)
5. Auto Handle TCP TIME-WAIT connection
