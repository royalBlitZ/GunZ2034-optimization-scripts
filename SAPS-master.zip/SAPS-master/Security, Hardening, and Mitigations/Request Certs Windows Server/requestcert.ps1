$computer = "$env:computername"
certreq.exe -accept $computer.txt
