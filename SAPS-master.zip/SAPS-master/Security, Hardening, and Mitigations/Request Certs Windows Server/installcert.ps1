$computer = "$env:computername"
certreq.exe -new ./initialrequest.txt $computer.txt
